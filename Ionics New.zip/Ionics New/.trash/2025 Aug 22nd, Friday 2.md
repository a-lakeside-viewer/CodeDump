---
tags:
  - dailynotes
date-created: "creation date: <% tp.file.creation_date() %>"
---
## To Do's

- [ ] 


## Notes
- 


