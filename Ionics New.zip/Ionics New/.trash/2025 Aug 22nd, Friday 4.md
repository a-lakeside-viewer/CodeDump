---
tags:
  - dailynotes
---
## To Do's

- [ ] 


## Notes
- 


## Files Created Today

```dataview
LIST Notes-Created-Today
FROM "Units" or "Notes" or "Technical Reports"
WHERE date(file.cday) = date(this.file.cday)
SORT file.name asc
```

## Files Modified Today

```dataview
LIST Notes-Created-Today
FROM "Units" or "Notes" or "Technical Reports"
WHERE date(file.mday) = date(this.file.mday)
SORT file.name asc
```