
---
- [ ] Perform 5S on setup, ⏫
- [ ] Check newly endorsed units in database and find their location, ⏫
- [ ] Check production-endorsed units' status, 🔼
- [ ] Update EMSRep data at the end of the day, 🔼