
---

## Reminders
-  RAD shipment is on ==Aug 22, 2025==


## + New FA Units



## Pending Tasks
```tasks
not done
```


## Pending Units


```dataview
TABLE For-Analysis
FROM "Units"
SORT file.name asc
```


