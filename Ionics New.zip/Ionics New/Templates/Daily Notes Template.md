---
tags:
  - dailynotes
---
## To Do's

###### Routine Tasks

- [ ] Perform 5S on setup, ⏫
- [ ] Check newly endorsed units in database and find their location, ⏫
- [ ] Check production-endorsed units' status, 🔼
- [ ] Update EMSRep data at the end of the day, 🔼

###### Extra Tasks

- [ ] 


## Notes

- 


## Files Created Today

```dataview
LIST Notes-Created-Today
FROM "Units" or "Notes" or "Technical Reports"
WHERE date(file.cday) = date(this.file.cday)
SORT file.name asc
```

## Files Modified Today

```dataview
LIST Notes-Created-Today
FROM "Units" or "Notes" or "Technical Reports"
WHERE date(file.mday) = date(this.file.mday)
SORT file.name asc
```