---
Account: Silicom
Model: Ibiza
PN:
Station:
Failure:
Specifics:
tags:
HandledOn: <% tp.file.creation_date() %>
Analysis:
DefectLocation:
Action:
UnitLocation:
To-Do:
---
---
## Status Switcher



---

## Notes

1. 

---

## Visual Inspection Results

| ITEM NO. | COMPONENT TYPE (i.e. capacitor, resistor) | COMPONENT LOCATION | DEFECT | Image/s |
| -------- | ----------------------------------------- | ------------------ | ------ | ------- |
| 1        |                                           |                    |        |         |

---

## Power Sequencing 



---

## Non-wetting CPU Checks


---

## Tera Term Commands


---

## Actions, Results, and Thoughts

| DATE & TIME | ACTION |
| ----------- | ------ |
|             |        
